import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from uuid import uuid4
from quiet_window import LOCKS, quiet_window

class QuietWindowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        for name in LOCKS:
            p = self.root / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(b"preserve-lock-content")
        self.inodes = {name: (self.root / name).stat().st_ino for name in LOCKS}
        self.children = []
    def tearDown(self):
        for child in self.children:
            if child.poll() is None: child.kill()
            child.communicate(timeout=3)
        self.temp.cleanup()
    def holder(self, timeout=3):
        job, nonce = str(uuid4()), "a" * 64
        child = subprocess.Popen([sys.executable, str(Path(__file__).with_name("quiet_window.py")), str(self.root), job, nonce, str(timeout)], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        self.children.append(child)
        self.assertEqual(json.loads(child.stdout.readline())["kind"], "ready")
        return child, job, nonce
    def send(self, child, job, nonce, operation="ping", sequence=1):
        child.stdin.write(json.dumps(dict(job_id=job, nonce=nonce, operation=operation, sequence=sequence)) + "\n")
        child.stdin.flush()
    def assert_available(self):
        with quiet_window(self.root): pass
    def test_holds_all_locks_without_truncating_or_replacing(self):
        child, job, nonce = self.holder()
        with self.assertRaises(BlockingIOError):
            with quiet_window(self.root): pass
        for name in LOCKS:
            self.assertEqual((self.root / name).read_bytes(), b"preserve-lock-content")
            self.assertEqual((self.root / name).stat().st_ino, self.inodes[name])
        self.send(child, job, nonce)
        self.assertEqual(json.loads(child.stdout.readline())["kind"], "alive")
        self.send(child, job, nonce, "release", 2)
        self.assertEqual(json.loads(child.stdout.readline())["kind"], "released")
        child.wait(timeout=3); self.assert_available()
    def test_holder_death_releases_every_lock(self):
        child, _, _ = self.holder();child.kill();child.wait(timeout=3);self.assert_available()
    def test_owner_eof_releases_every_lock(self):
        child, _, _ = self.holder();child.stdin.close();child.stdin=None
        self.assertNotEqual(child.wait(timeout=3), 0);self.assert_available()
    def test_expired_heartbeat_releases_every_lock(self):
        child, _, _ = self.holder(.1)
        self.assertNotEqual(child.wait(timeout=3), 0);self.assert_available()
    def test_wrong_job_cannot_keep_lease(self):
        child, _, nonce = self.holder();self.send(child,str(uuid4()),nonce)
        self.assertNotEqual(child.wait(timeout=3), 0);self.assert_available()
    def test_replayed_sequence_cannot_keep_lease(self):
        child, job, nonce = self.holder();self.send(child,job,nonce,sequence=0)
        self.assertNotEqual(child.wait(timeout=3), 0);self.assert_available()
    def test_no_ack_or_arbitrary_command_protocol(self):
        child, job, nonce = self.holder();self.send(child,job,nonce,"ack")
        self.assertNotEqual(child.wait(timeout=3), 0);self.assert_available()
    def test_missing_last_lock_releases_first_two(self):
        target=self.root/LOCKS[-1];target.unlink()
        with self.assertRaises(FileNotFoundError):
            with quiet_window(self.root):pass
        target.write_bytes(b"");self.assert_available()
    def test_symlink_lock_rejected(self):
        target=self.root/LOCKS[-1];target.unlink();target.symlink_to(self.root/LOCKS[0])
        with self.assertRaises(OSError):
            with quiet_window(self.root):pass
    def test_replaced_inode_invalidates_holder(self):
        child, job, nonce=self.holder();target=self.root/LOCKS[-1];target.unlink();target.write_bytes(b"")
        self.send(child,job,nonce);self.assertNotEqual(child.wait(timeout=3),0);self.assert_available()
if __name__ == "__main__":unittest.main()
