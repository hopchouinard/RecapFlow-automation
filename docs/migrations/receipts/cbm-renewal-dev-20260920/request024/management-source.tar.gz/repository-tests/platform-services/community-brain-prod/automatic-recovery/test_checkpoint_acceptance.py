import json
from pathlib import Path
import sys
import tempfile
import unittest
from uuid import uuid4

from checkpoint_acceptance import REQUIRED, acknowledge, atomic, sha, validate
from lease_supervisor import LeaseSupervisor
from quiet_window import LOCKS


def fixture(root, job):
    directory = root / 'artifacts/automatic' / job
    directory.mkdir(parents=True, mode=0o700)
    (root/'automation/checkpoints').mkdir(parents=True)
    for name in LOCKS:
        p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.touch();p.chmod(0o600)
    for name in REQUIRED:
        p=directory/name;p.write_bytes(b'fixture');p.chmod(0o600)
    corpus={'rows':2,'sessions':{'old':'a'*64,'new':'b'*64},'dimensions':768,'fts_indexed':2,'fts_unindexed':0}
    atomic(directory/'corpus-before.json',corpus)
    atomic(directory/'database-capture.json',{'job_id':job,'dump':{'sha256':sha(directory/'database.dump')}})
    atomic(directory/'files-capture.json',{'job_id':job,'archive':{'sha256':sha(directory/'managed-state.tar.gz')}})
    atomic(directory/'database-restore.json',{'job_id':job,'dump_sha256':sha(directory/'database.dump'),
      'capture_sha256':sha(directory/'database-capture.json'),'schema_owners_grants_rows_sequences_match':True})
    atomic(directory/'files-restore.json',{'job_id':job,'archive_sha256':sha(directory/'managed-state.tar.gz'),
      'capture_sha256':sha(directory/'files-capture.json'),'temporary_restore_removed':True,'corpus':corpus})
    files={n:{'sha256':sha(directory/n),'bytes':(directory/n).stat().st_size} for n in REQUIRED}
    atomic(directory/'paired-manifest.json',{'job_id':job,'files':files})
    digest=sha(directory/'paired-manifest.json')
    atomic(directory/'offhost-copy.json',{'job_id':job,'verified':True,'files':{**files,'paired-manifest.json':{'sha256':digest,'bytes':(directory/'paired-manifest.json').stat().st_size}}})
    atomic(directory/'pbs-receipt.json',{'job_id':job,'manifest_sha256':digest,'status':'OK',
      'guest_freeze_thaw':True,'included_disks':['scsi0','scsi1'],'snapshot':'pbs:backup/vm/109/2026-09-10T20:00:00Z'})
    atomic(root/'automation/checkpoint-needed.json',{'job_id':job,'policy':'new-meeting-full-loop-v1'})
    return directory,digest


class AcceptanceTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.job=str(uuid4())
        self.directory,self.digest=fixture(self.root,self.job)

    def test_acknowledgment_inside_real_lock_holder(self):
        command=[sys.executable,str(Path(__file__).with_name('quiet_window.py')),str(self.root),self.job,'a'*64,'5','ack-enabled']
        with LeaseSupervisor(command,self.job,'a'*64,interval=.05,reply_timeout=2) as lease:
            lease.acknowledge(self.digest)
        self.assertFalse((self.root/'automation/checkpoint-needed.json').exists())
        target=self.root/'automation/checkpoints'/f'{self.job}.json'
        self.assertEqual(json.loads(target.read_text())['manifest_sha256'],self.digest)
        self.assertEqual(target.stat().st_mode&0o777,0o600)

    def test_corrupted_actual_file_not_accepted(self):
        (self.directory/'database.dump').write_bytes(b'changed')
        with self.assertRaises(ValueError):acknowledge(self.root,self.job,self.digest,lambda:None)
        self.assertTrue((self.root/'automation/checkpoint-needed.json').exists())

    def test_wrong_manifest_rejected(self):
        with self.assertRaises(ValueError):validate(self.root,self.job,'0'*64)

    def test_wrong_marker_job_rejected(self):
        atomic(self.root/'automation/checkpoint-needed.json',{'job_id':str(uuid4()),'policy':'new-meeting-full-loop-v1'})
        with self.assertRaises(ValueError):acknowledge(self.root,self.job,self.digest,lambda:None)

    def test_partial_copy_rejected(self):
        p=self.directory/'offhost-copy.json';data=json.loads(p.read_text());data['files'].pop('database.dump');atomic(p,data)
        with self.assertRaises(ValueError):validate(self.root,self.job,self.digest)

    def test_failed_pbs_rejected(self):
        p=self.directory/'pbs-receipt.json';data=json.loads(p.read_text());data['status']='failed';atomic(p,data)
        with self.assertRaises(ValueError):validate(self.root,self.job,self.digest)

    def test_wrong_snapshot_group_rejected(self):
        p=self.directory/'pbs-receipt.json';data=json.loads(p.read_text());data['snapshot']=data['snapshot'].replace('/109/','/108/');atomic(p,data)
        with self.assertRaises(ValueError):validate(self.root,self.job,self.digest)

    def test_lost_holder_cannot_acknowledge(self):
        def failed():raise RuntimeError('lost')
        with self.assertRaises(RuntimeError):acknowledge(self.root,self.job,self.digest,failed)
        self.assertFalse((self.root/'automation/checkpoints'/f'{self.job}.json').exists())

    def test_crash_after_ack_before_marker_removal_reconciles_without_rewrite(self):
        calls=0
        def interrupt():
            nonlocal calls
            calls+=1
            if calls==3:raise RuntimeError('crash after durable acknowledgment')
        with self.assertRaises(RuntimeError):acknowledge(self.root,self.job,self.digest,interrupt)
        target=self.root/'automation/checkpoints'/f'{self.job}.json';before=target.read_bytes()
        self.assertTrue((self.root/'automation/checkpoint-needed.json').exists())
        acknowledge(self.root,self.job,self.digest,lambda:None)
        self.assertEqual(target.read_bytes(),before)
        self.assertFalse((self.root/'automation/checkpoint-needed.json').exists())

    def test_conflicting_existing_acknowledgment_rejected(self):
        atomic(self.root/'automation/checkpoints'/f'{self.job}.json',{'job_id':self.job,'verified':True,'manifest_sha256':'0'*64})
        with self.assertRaises(ValueError):acknowledge(self.root,self.job,self.digest,lambda:None)

    def test_evidence_symlink_rejected(self):
        p=self.directory/'pbs-receipt.json';p.rename(p.with_name('saved'));p.symlink_to(p.with_name('saved'))
        with self.assertRaises(ValueError):validate(self.root,self.job,self.digest)


if __name__=='__main__':unittest.main()
