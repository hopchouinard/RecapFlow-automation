import hashlib
import json
import os
from pathlib import Path
import tempfile
import unittest
from uuid import uuid4
from files_adapter import capture, extract_verified, inventory, check_references


class FilesAdapterTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)
        self.source = self.base / "source"
        self.file = self.source / "srv/community-brain/files/test.md"
        self.file.parent.mkdir(parents=True)
        self.file.write_text("disposable meeting")
        self.file.chmod(0o640)
        self.folders = ["srv/community-brain/files"]
        self.out = self.base / "checkpoint"
        self.job = str(uuid4())

    def test_dynamic_capture_restore_and_references(self):
        for index in range(17):
            (self.file.parent / f"extra{index}").write_text(str(index))
        saved = capture(self.source, self.folders, self.out, self.job)
        dest = self.base / "restore"
        extract_verified(self.out, dest, self.job)
        self.assertEqual(inventory(dest, self.folders), saved["files"])
        refs = [{"path": "test.md", "sha256": hashlib.sha256(self.file.read_bytes()).hexdigest(), "size": self.file.stat().st_size}]
        check_references(dest, refs)
        self.assertEqual((dest / "srv/community-brain/files/test.md").stat().st_mode & 0o777, 0o640)

    def test_symlinks_rejected(self):
        (self.file.parent / "linked").symlink_to(self.file)
        with self.assertRaises(ValueError):
            capture(self.source, self.folders, self.out, self.job)

    def test_hardlinks_rejected(self):
        os.link(self.file, self.file.parent / "hardlinked")
        with self.assertRaises(ValueError):
            capture(self.source, self.folders, self.out, self.job)

    def test_existing_capture_cannot_be_repeated(self):
        capture(self.source, self.folders, self.out, self.job)
        with self.assertRaises(FileExistsError):
            capture(self.source, self.folders, self.out, self.job)

    def test_wrong_job_rejected(self):
        capture(self.source, self.folders, self.out, self.job)
        with self.assertRaises(ValueError):
            extract_verified(self.out, self.base / "restore", str(uuid4()))

    def test_corrupt_archive_rejected(self):
        capture(self.source, self.folders, self.out, self.job)
        with (self.out / "managed-state.tar.gz").open("ab") as stream:
            stream.write(b"corrupt")
        with self.assertRaises(ValueError):
            extract_verified(self.out, self.base / "restore", self.job)

    def test_manifest_missing_member_rejected(self):
        capture(self.source, self.folders, self.out, self.job)
        path = self.out / "files-capture.json"
        saved = json.loads(path.read_text())
        del saved["files"]["srv/community-brain/files/test.md"]
        path.write_text(json.dumps(saved))
        with self.assertRaises(ValueError):
            extract_verified(self.out, self.base / "restore", self.job)

    def test_reference_mismatch_rejected(self):
        with self.assertRaises(ValueError):
            check_references(self.source, [{"path": "test.md", "sha256": "0" * 64, "size": None}])

    def test_reference_traversal_rejected(self):
        with self.assertRaises(ValueError):
            check_references(self.source, [{"path": "../escape", "sha256": "0" * 64, "size": None}])


if __name__ == "__main__":
    unittest.main()
