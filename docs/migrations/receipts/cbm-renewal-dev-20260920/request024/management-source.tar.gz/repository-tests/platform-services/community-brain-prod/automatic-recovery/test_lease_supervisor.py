import os
from pathlib import Path
import signal
import sys
import tempfile
import threading
import time
import unittest
from uuid import uuid4

from lease_supervisor import LeaseLost, LeaseSupervisor
from quiet_window import LOCKS, quiet_window


class SupervisorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        for name in LOCKS:
            p = self.root / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text("")
        self.job, self.nonce = str(uuid4()), "b" * 64
        self.leases = []

    def tearDown(self):
        for lease in self.leases:
            lease.close()
        self.temp.cleanup()

    def lease(self, command=None):
        if command is None:
            command = [sys.executable, str(Path(__file__).with_name("quiet_window.py")),
                       str(self.root), self.job, self.nonce, "2"]
        lease = LeaseSupervisor(command, self.job, self.nonce,
                                interval=.03, reply_timeout=1)
        # Interpreter startup on a busy Mac is not the heartbeat deadline under
        # test. Tighten the bound only after the holder has reported ready.
        lease.reply_timeout=.15
        self.leases.append(lease)
        return lease

    def test_success_keeps_locks_and_releases_cleanly(self):
        with self.lease() as lease:
            lease.run([sys.executable, "-c", "import time; time.sleep(.2)"], timeout=2)
            with self.assertRaises(BlockingIOError):
                with quiet_window(self.root):
                    pass
        self.assertFalse(lease.failed.is_set())
        with quiet_window(self.root):
            pass
        with self.assertRaises(LeaseLost):
            lease.check()

    def test_holder_death_aborts_effect_before_late_write(self):
        lease = self.lease()
        late = self.root / "late"
        timer = threading.Timer(.1, lease.process.kill)
        timer.start()
        started = time.monotonic()
        try:
            with self.assertRaises(LeaseLost):
                lease.run([sys.executable, "-c",
                           "import time,pathlib,sys; time.sleep(2); pathlib.Path(sys.argv[1]).touch()", str(late)], timeout=4)
        finally:
            timer.join()
        self.assertLess(time.monotonic() - started, 1)
        self.assertFalse(late.exists())

    def test_unresponsive_holder_aborts_on_heartbeat_deadline(self):
        lease = self.lease()
        timer = threading.Timer(.08, lambda: os.kill(lease.process.pid, signal.SIGSTOP))
        timer.start()
        started = time.monotonic()
        try:
            with self.assertRaises(LeaseLost):
                lease.run([sys.executable, "-c", "import time; time.sleep(5)"], timeout=6)
        finally:
            timer.join()
        self.assertLess(time.monotonic() - started, 1)

    def test_inode_replacement_aborts_effect(self):
        lease = self.lease()
        def replace():
            p = self.root / LOCKS[-1]
            p.unlink()
            p.touch()
        timer = threading.Timer(.08, replace)
        timer.start()
        try:
            with self.assertRaises(LeaseLost):
                lease.run([sys.executable, "-c", "import time; time.sleep(5)"], timeout=6)
        finally:
            timer.join()

    def test_failed_effect_does_not_claim_success(self):
        lease = self.lease()
        with self.assertRaisesRegex(RuntimeError, "reconcile intent"):
            lease.run([sys.executable, "-c", "raise SystemExit(7)"], timeout=2)
        lease.check()

    def test_deadline_aborts_effect(self):
        lease = self.lease()
        with self.assertRaisesRegex(TimeoutError, "reconcile intent"):
            lease.run([sys.executable, "-c", "import time; time.sleep(5)"], timeout=.1)
        lease.check()

    def test_wrong_ready_identity_rejected(self):
        code = "import json; print(json.dumps(dict(kind='ready', sequence=0, job_id='wrong', nonce='wrong')), flush=True)"
        with self.assertRaises(LeaseLost):
            self.lease([sys.executable, "-c", code])

    def test_dead_holder_cannot_start_an_effect(self):
        lease = self.lease()
        lease.process.kill()
        lease.process.wait(timeout=2)
        marker = self.root / "never"
        with self.assertRaises(LeaseLost):
            lease.run([sys.executable, "-c", "import pathlib,sys; pathlib.Path(sys.argv[1]).touch()", str(marker)], timeout=2)
        self.assertFalse(marker.exists())

    def test_effect_descendants_are_terminated(self):
        lease = self.lease()
        marker = self.root / "descendant-late"
        child_code = "import time,pathlib,sys; time.sleep(1); pathlib.Path(sys.argv[1]).touch()"
        code = "import subprocess,sys,time; subprocess.Popen([sys.executable,'-c',sys.argv[1],sys.argv[2]]); time.sleep(5)"
        with self.assertRaises(TimeoutError):
            lease.run([sys.executable, "-c", code, child_code, str(marker)], timeout=.15)
        time.sleep(1.1)
        self.assertFalse(marker.exists())


if __name__ == "__main__":
    unittest.main()
