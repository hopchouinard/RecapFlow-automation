import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from uuid import uuid4
import pbs_adapter as pbs


class PbsTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.job=str(uuid4());self.hash='a'*64
        self.calls=[];self.status={'status':'stopped','exitstatus':'OK'}
        self.old='pbs:backup/vm/109/2026-09-09T20:00:00Z'
        self.new='pbs:backup/vm/109/2026-09-10T20:00:00Z'
        self.notes='CBM automatic '+self.job+' '+self.hash
        self.log="include disk 'scsi0'\ninclude disk 'scsi1'\ncreating Proxmox Backup Server archive 'vm/109/2026-09-10T20:00:00Z'\nfs-freeze\nfs-thaw"
        self.submitted=False;self.fail_submit=False;self.prior_present=True
        for context in [patch.object(pbs,'BASE',self.root),patch.object(pbs,'api',self.api)]:
            context.start();self.addCleanup(context.stop)

    def api(self,*args):
        self.calls.append(args)
        if args[0]=='create':
            self.submitted=True
            if self.fail_submit:raise TimeoutError('unknown submission outcome')
            return 'UPID:pve1:fixture'
        if args[1].endswith('/config'):return {'scsi0':'disk0','scsi1':'disk1','agent':'enabled=1'}
        if args[1].endswith('/content'):
            values=[{'volid':self.old}] if self.prior_present else []
            if self.submitted:values.append({'volid':self.new,'notes':self.notes})
            return values
        if args[1].endswith('/status'):return self.status
        if args[1].endswith('/log'):return [{'t':line} for line in self.log.splitlines()]
        raise AssertionError(args)

    def test_success_retains_prior_snapshots_and_binds_notes(self):
        pbs.start(self.job,self.hash);receipt=pbs.inspect(self.job,self.hash)
        self.assertEqual(receipt['status'],'OK');self.assertEqual(receipt['snapshot'],self.new)
        creation=next(c for c in self.calls if c[0]=='create')
        self.assertEqual(creation[creation.index('--remove')+1],'0')
        self.assertEqual(pbs.inspect(self.job,self.hash),receipt)

    def test_duplicate_does_not_resubmit(self):
        pbs.start(self.job,self.hash)
        with self.assertRaises(FileExistsError):pbs.start(self.job,self.hash)
        self.assertEqual(sum(c[0]=='create' for c in self.calls),1)

    def test_unknown_submission_preserves_intent_and_forbids_retry(self):
        self.fail_submit=True
        with self.assertRaises(TimeoutError):pbs.start(self.job,self.hash)
        self.assertEqual(json.loads((self.root/self.job/'operation.json').read_text())['state'],'intent')
        with self.assertRaises(FileExistsError):pbs.start(self.job,self.hash)
        with self.assertRaises(ValueError):pbs.inspect(self.job,self.hash)

    def test_failed_task_not_accepted(self):
        pbs.start(self.job,self.hash);self.status['exitstatus']='ERROR'
        with self.assertRaises(ValueError):pbs.inspect(self.job,self.hash)

    def test_missing_thaw_not_accepted(self):
        pbs.start(self.job,self.hash);self.log=self.log.replace('fs-thaw','')
        with self.assertRaises(ValueError):pbs.inspect(self.job,self.hash)

    def test_wrong_snapshot_notes_not_accepted(self):
        pbs.start(self.job,self.hash);self.notes='wrong'
        with self.assertRaises(ValueError):pbs.inspect(self.job,self.hash)

    def test_lost_old_snapshot_not_accepted(self):
        pbs.start(self.job,self.hash);self.prior_present=False
        with self.assertRaises(ValueError):pbs.inspect(self.job,self.hash)

    def test_running_task_is_only_polled(self):
        pbs.start(self.job,self.hash);self.status={'status':'running'}
        self.assertEqual(pbs.inspect(self.job,self.hash)['state'],'running')
        self.assertEqual(sum(c[0]=='create' for c in self.calls),1)

    def test_wrong_manifest_not_accepted(self):
        pbs.start(self.job,self.hash)
        with self.assertRaises(ValueError):pbs.inspect(self.job,'b'*64)


if __name__=='__main__':unittest.main()
