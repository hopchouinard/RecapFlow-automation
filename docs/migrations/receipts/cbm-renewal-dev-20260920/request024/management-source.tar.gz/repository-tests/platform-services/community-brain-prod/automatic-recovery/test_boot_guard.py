import json
from pathlib import Path
import tempfile
import unittest
from boot_guard import enforce
from checkpoint_acceptance import atomic


class BootGuardTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name)
    def test_new_boot_pauses(self):
        self.assertFalse(enforce(self.root,'boot-a'));self.assertTrue((self.root/'paused').exists())
    def test_same_boot_does_not_infer_reconciliation(self):
        enforce(self.root,'boot-a');(self.root/'paused').unlink();self.assertFalse(enforce(self.root,'boot-a'))
    def test_explicit_reconciliation_allows_same_boot(self):
        enforce(self.root,'boot-a');atomic(self.root/'boot-state.json',{'boot_id':'boot-a','reconciled':True});(self.root/'paused').unlink()
        self.assertTrue(enforce(self.root,'boot-a'))
    def test_restored_old_boot_pauses_before_launcher(self):
        atomic(self.root/'boot-state.json',{'boot_id':'old-boot','reconciled':True})
        self.assertFalse(enforce(self.root,'new-boot'));self.assertTrue((self.root/'paused').exists())
    def test_boot_service_forces_pause_even_if_identifier_matches(self):
        atomic(self.root/'boot-state.json',{'boot_id':'boot-a','reconciled':True})
        self.assertFalse(enforce(self.root,'boot-a',force=True))


if __name__=='__main__':unittest.main()
