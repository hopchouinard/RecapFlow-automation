import datetime
import unittest
from maintain import hourly_due


class SchedulerTests(unittest.TestCase):
    def test_minute_tick_does_not_repeat_hourly_effects(self):
        self.assertFalse(hourly_due(1000,950,datetime.datetime(2026,9,10,16,45)))
    def test_hourly_due(self):
        self.assertTrue(hourly_due(4600,1000,datetime.datetime(2026,9,10,16,45)))
    def test_existing_local_pre_pbs_calendar_kept_even_if_hourly_not_due(self):
        for month in (1,9):
            self.assertTrue(hourly_due(1000,950,datetime.datetime(2026,month,10,20,45)))
    def test_other_calendar_minute_not_forced(self):
        self.assertFalse(hourly_due(1000,950,datetime.datetime(2026,9,10,20,44)))
    def test_calendar_and_interval_delivery_in_same_minute_do_not_repeat(self):
        self.assertFalse(hourly_due(1025,1001,datetime.datetime(2026,9,10,20,45,25)))


if __name__=='__main__':unittest.main()
