import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import effective_packet as packet


class EffectivePacketTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        self.base, self.supplement, self.destination = [root / n for n in ("base", "supplement", "effective")]
        self.base.mkdir()
        self.supplement.mkdir()
        names = ["jobs/api.py", "automatic_host.py", "rehearsal/check.py", "rehearsal/fixtures.py"] + [f"jobs/file{n}.py" for n in range(23)]
        specs = {}
        for name in names:
            data = ("original:" + name).encode()
            p = self.base / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(data)
            specs[name] = {"sha256": packet.digest(data), "bytes": len(data)}
        raw = json.dumps({"image": "fixture-image", "files": specs}).encode()
        (self.base / "packet-manifest.json").write_bytes(raw)
        manifest = {"request_id": "CBM-AUTOMATIC-20260910-011", "supplement": "01", "files": {}}
        replacements = {}
        for name in ("jobs/api.py", "automatic_host.py"):
            simple = Path(name).name
            data = ("replacement:" + name).encode()
            (self.supplement / simple).write_bytes(data)
            replacements[name] = (simple, packet.digest(data))
            manifest["files"][simple] = {"sha256": packet.digest(data), "bytes": len(data), "original_sha256": specs[name]["sha256"]}
        (self.supplement / "manifest.json").write_text(json.dumps(manifest))
        for context in (patch.object(packet, "BASE_MANIFEST", packet.digest(raw)), patch.object(packet, "REPLACEMENTS", replacements)):
            context.start()
            self.addCleanup(context.stop)

    def build(self):
        return packet.build(self.base, self.supplement, self.destination)

    def test_exact_subset_excludes_rehearsal_and_unlisted_cache(self):
        (self.base / "unlisted-secret.env").write_text("never copy")
        cache = self.base / "__pycache__"
        cache.mkdir()
        (cache / "file.pyc").write_bytes(b"cache")
        result = self.build()
        self.assertEqual(len(result["files"]), 25)
        self.assertFalse((self.destination / "rehearsal").exists())
        self.assertFalse((self.destination / "unlisted-secret.env").exists())
        self.assertFalse((self.destination / "__pycache__").exists())
        self.assertEqual((self.destination / "jobs/api.py").read_text(), "replacement:jobs/api.py")
        self.assertEqual((self.destination / "jobs/api.py").stat().st_mode & 0o777, 0o644)
        self.assertEqual((self.destination / "jobs").stat().st_mode & 0o777, 0o755)

    def test_original_manifest_tamper_rejected(self):
        (self.base / "packet-manifest.json").write_text("{}")
        with self.assertRaises(ValueError):
            self.build()
        self.assertFalse(self.destination.exists())

    def test_original_member_tamper_rejected_even_if_replaced(self):
        (self.base / "jobs/api.py").write_text("bad")
        with self.assertRaises(ValueError):
            self.build()
        self.assertFalse(self.destination.exists())

    def test_excluded_rehearsal_tamper_still_rejected(self):
        (self.base / "rehearsal/check.py").write_text("bad")
        with self.assertRaises(ValueError):
            self.build()

    def test_replacement_tamper_rejected(self):
        (self.supplement / "api.py").write_text("bad")
        with self.assertRaises(ValueError):
            self.build()

    def test_existing_destination_never_overwritten(self):
        self.build()
        marker = self.destination / "owned-by-prior-attempt"
        marker.write_text("preserve")
        with self.assertRaises(FileExistsError):
            self.build()
        self.assertEqual(marker.read_text(), "preserve")

    def test_member_symlink_rejected(self):
        p = self.base / "jobs/api.py"
        p.rename(p.with_name("saved"))
        p.symlink_to(p.with_name("saved"))
        with self.assertRaises(ValueError):
            self.build()

    def test_wrong_supplement_identity_rejected(self):
        p = self.supplement / "manifest.json"
        m = json.loads(p.read_text())
        m["request_id"] = "another-job"
        p.write_text(json.dumps(m))
        with self.assertRaises(ValueError):
            self.build()

    def test_traversal_rejected(self):
        with self.assertRaises(ValueError):
            packet.checked_read(self.base, "../anything", "0" * 64)


if __name__ == "__main__":
    unittest.main()
