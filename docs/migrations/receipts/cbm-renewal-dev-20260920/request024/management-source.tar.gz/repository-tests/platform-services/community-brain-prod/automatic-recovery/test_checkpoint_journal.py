import json
from pathlib import Path
import tempfile
import unittest
from uuid import uuid4
from checkpoint_journal import Journal,PHASES,ReconciliationRequired

class JournalTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.job=str(uuid4());self.inputs={"marker_sha256":"a"*64,"packet":"b"*64};self.alive=True;self.effects=[]
    def lease(self):
        if not self.alive:raise ReconciliationRequired("holder lost")
    def journal(self):return Journal(self.temp.name,self.job,self.inputs,self.lease)
    def effect(self,phase):self.effects.append(phase);return {"job_id":self.job,"phase_result":phase}
    def complete(self):
        for phase in PHASES:self.journal().run(phase,lambda p=phase:self.effect(p))
    def test_repeated_delivery_after_every_boundary_never_repeats_effects(self):
        for phase in PHASES:
            self.journal().run(phase,lambda p=phase:self.effect(p))
            self.journal().run(phase,lambda:self.fail("completed operation repeated"))
        self.assertEqual(self.effects,list(PHASES))
    def test_restart_inside_every_boundary_requires_reconciliation(self):
        for failing in PHASES:
            with self.subTest(phase=failing),tempfile.TemporaryDirectory() as tmp:
                j=Journal(tmp,self.job,self.inputs,self.lease)
                for p in PHASES[:PHASES.index(failing)]:j.run(p,lambda p=p:self.effect(p))
                def crash():raise RuntimeError("interrupted external step")
                with self.assertRaises(RuntimeError):j.run(failing,crash)
                resumed=Journal(tmp,self.job,self.inputs,self.lease)
                with self.assertRaises(ReconciliationRequired):resumed.run(failing,lambda:self.fail("uncertain effect repeated"))
    def test_holder_loss_before_operation_prevents_effect(self):
        self.alive=False
        with self.assertRaises(ReconciliationRequired):self.journal().run(PHASES[0],lambda:self.fail("must not run"))
    def test_holder_loss_after_operation_prevents_complete_record(self):
        def effect():self.alive=False;return {"job_id":self.job}
        with self.assertRaises(ReconciliationRequired):self.journal().run(PHASES[0],effect)
        self.alive=True
        with self.assertRaises(ReconciliationRequired):self.journal().read(PHASES[0])
    def test_wrong_job_result_never_completes(self):
        with self.assertRaises(ReconciliationRequired):self.journal().run(PHASES[0],lambda:{"job_id":str(uuid4())})
    def test_wrong_manifest_inputs_reject_previous_receipts(self):
        self.journal().run(PHASES[0],lambda:self.effect(PHASES[0]));self.inputs={"marker_sha256":"c"*64}
        with self.assertRaises(ReconciliationRequired):self.journal().read(PHASES[0])
    def test_corrupt_receipt_rejected(self):
        j=self.journal();j.run(PHASES[0],lambda:self.effect(PHASES[0]));p=j.root/(PHASES[0]+".json");d=json.loads(p.read_text());d['receipt']['job_id']=str(uuid4());p.write_text(json.dumps(d))
        with self.assertRaises(ReconciliationRequired):j.read(PHASES[0])
    def test_out_of_order_pbs_is_rejected(self):
        with self.assertRaises(ReconciliationRequired):self.journal().run("pbs",lambda:self.fail("premature PBS"))
    def test_shape_only_flags_cannot_acknowledge(self):
        self.complete()
        with self.assertRaises(ReconciliationRequired):self.journal().verified_manifest(lambda *_:{"verified":True})
    def test_live_verification_required_even_for_completed_journal(self):
        self.complete();calls=[]
        self.assertEqual(self.journal().verified_manifest(lambda job,r:(calls.append((job,len(r))) or "d"*64)),"d"*64)
        self.assertEqual(calls,[(self.job,len(PHASES))])
    def test_failed_copy_or_pbs_verification_cannot_acknowledge(self):
        self.complete()
        def verify(*_):raise ReconciliationRequired("copied set or PBS mismatch")
        with self.assertRaises(ReconciliationRequired):self.journal().verified_manifest(verify)
    def test_holder_loss_during_final_verification_prevents_acceptance(self):
        self.complete()
        def verify(*_):self.alive=False;return "d"*64
        with self.assertRaises(ReconciliationRequired):self.journal().verified_manifest(verify)
if __name__=='__main__':unittest.main()
