// Execute the production adapter with a delayed application-ready event.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const {EventEmitter} = require('node:events');
const source = fs.readFileSync(__dirname + '/renewal_kuma.js', 'utf8');
const input = {old:'fixture-old',token:'fixture-new',cycle:'00000000-0000-4000-8000-000000000001'};
const monitor={name:'community-brain-production-retrieval',active:1,headers:JSON.stringify({Authorization:'Bearer '+input.old}),url:'https://fixture/retrieval/query',method:'POST'};
let appReady=false, loginCalled=false, expiredAdminToken=false;
class Socket extends EventEmitter {
  connect() {
    super.emit('connect');
    setTimeout(()=>{appReady=true;super.emit('info',{});},10);
  }
  timeout() { return {emit:(event,...args)=>{
    const callback=args.pop();
    if(event==='loginByToken') { assert(appReady,'login raced application readiness');loginCalled=true; }
    if(event==='getMonitorList') super.emit('monitorList',{31:monitor});
    if(event==='editMonitor') Object.assign(monitor,args[0]);
    callback(null,{ok:true});
  }}; }
  close() {}
}
class Database {
  get(sql,args,cb) {
    if(sql.includes('setting')) return cb(null,{value:'fixture-admin-key'});
    if(sql.includes('user')) return cb(null,{username:'fixture',password:'fixture'});
    cb(null,monitor);
  }
  close() {}
}
const imports={
  jsonwebtoken:{sign:(value,key,options)=>{assert.equal(options.expiresIn,180);expiredAdminToken=true;return 'fixture-jwt';}},
  fs:{readFileSync:()=>JSON.stringify(input),existsSync:()=>true,writeFileSync:()=>{}},
  '@louislam/sqlite3':{verbose:()=>({Database})},
  'socket.io-client':{io:(url,options)=>{assert.equal(options.autoConnect,false);return new Socket();}},
  '/app/server/util-server':{shake256:()=>'',SHAKE256_LENGTH:10}
};
vm.runInNewContext(source,{require:name=>imports[name],setTimeout,clearTimeout,
  console:{log:text=>{const r=JSON.parse(text);assert(r.credential_updated);assert(loginCalled&&expiredAdminToken);console.log('Kuma delayed-readiness and expiring-admin-token regression passed');},error:()=>assert.fail('adapter failed')},
  process:{exit:()=>assert.fail('unexpected exit')}});
