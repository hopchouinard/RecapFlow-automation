"""Build an immutable, inactive production subset from pinned sender inputs."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import tempfile

BASE_MANIFEST = "e5ae39ce6bd7f1a5656dc97a09e97b249135bf9eeb6c4b02e0d78e3ceabb6d9b"
REPLACEMENTS = {
    "jobs/api.py": ("api.py", "86e0a15ce3eeeb4cebb3b2c15627ed3cc9e62b93854b88ac233a30c262500ba4"),
    "automatic_host.py": ("automatic_host.py", "e6ffdfb624a91dea4cfd96c59e0a3408eadf3168282f6d37d805da7e8a188e5f"),
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def checked_read(root, name, sha, size=None):
    path = PurePosixPath(name)
    if path.is_absolute() or ".." in path.parts or not path.parts:
        raise ValueError("invalid packet member")
    current = Path(root)
    for part in path.parts:
        current = current / part
        if current.is_symlink():
            raise ValueError("symlink packet member")
    data = current.read_bytes()
    if digest(data) != sha or (size is not None and len(data) != size):
        raise ValueError("packet member hash or size mismatch")
    return data


def build(base, supplement, destination):
    base, supplement, destination = map(Path, (base, supplement, destination))
    if destination.exists() or destination.is_symlink():
        raise FileExistsError("effective packet already exists; verify instead of overwrite")
    raw = checked_read(base, "packet-manifest.json", BASE_MANIFEST)
    manifest = json.loads(raw)
    supplement_raw = (supplement / "manifest.json").read_bytes()
    supplement_manifest = json.loads(supplement_raw)
    if supplement_manifest.get("request_id") != "CBM-AUTOMATIC-20260910-011" or supplement_manifest.get("supplement") != "01":
        raise ValueError("wrong supplement identity")
    content = {}
    excluded = []
    for name, evidence in manifest["files"].items():
        data = checked_read(base, name, evidence["sha256"], evidence["bytes"])
        if name.startswith("rehearsal/"):
            excluded.append(name)
            continue
        if name in REPLACEMENTS:
            replacement, expected = REPLACEMENTS[name]
            spec = supplement_manifest["files"][replacement]
            if spec["original_sha256"] != evidence["sha256"] or spec["sha256"] != expected:
                raise ValueError("supplement original or replacement pin mismatch")
            data = checked_read(supplement, replacement, expected, spec["bytes"])
        content[name] = data
    if len(content) != 25 or sorted(excluded) != ["rehearsal/check.py", "rehearsal/fixtures.py"]:
        raise ValueError("unexpected production subset")
    receipt = {"request_id": "CBM-AUTOMATIC-20260910-011", "image": manifest["image"],
               "original_packet_manifest_sha256": digest(raw),
               "supplement_manifest_sha256": digest(supplement_raw),
               "excluded": excluded, "activation": "held", "files": {
                   name: {"sha256": digest(data), "bytes": len(data)}
                   for name, data in sorted(content.items())}}
    # Build outside the final path. Never replace an existing packet directory.
    temporary = Path(tempfile.mkdtemp(prefix=".effective-011-", dir=destination.parent))
    try:
        for name, data in content.items():
            path = temporary / name
            path.parent.mkdir(parents=True, exist_ok=True, mode=0o755)
            with path.open("xb") as f:
                os.fchmod(f.fileno(), 0o644)
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
        path = temporary / "effective-manifest.json"
        with path.open("x") as f:
            os.fchmod(f.fileno(), 0o600)
            json.dump(receipt, f, indent=2, sort_keys=True)
            f.write("\n")
            f.flush()
            os.fsync(f.fileno())
        # mkdir claims the destination atomically; copying into it is deliberately
        # not an activation operation and cannot replace another actor's packet.
        destination.mkdir(mode=0o755)
        for path in temporary.iterdir():
            path.rename(destination / path.name)
        # UID10001 must traverse/read mounted code; private host ancestors keep
        # the staging workspace inaccessible to ordinary host users.
        destination.chmod(0o755)
        for path in destination.rglob("*"):
            if path.is_dir():
                path.chmod(0o755)
        if {str(p.relative_to(destination)) for p in destination.rglob("*") if p.is_file()} != set(content) | {"effective-manifest.json"}:
            raise ValueError("effective packet contains unexpected files")
        for name, spec in receipt["files"].items():
            checked_read(destination, name, spec["sha256"], spec["bytes"])
        receipt["effective_manifest_sha256"] = digest((destination / "effective-manifest.json").read_bytes())
        return receipt
    finally:
        shutil.rmtree(temporary)
