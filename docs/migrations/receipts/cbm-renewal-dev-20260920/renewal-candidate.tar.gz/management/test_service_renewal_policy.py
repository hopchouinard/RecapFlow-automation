import copy
import hashlib
import json
import unittest
from service_renewal_policy import SPECS, IDENTITIES, PENDING, LIFETIME, LEAD, due, run


def initial(now=1000000):
    v, records = {}, []
    for key, expiry, subject, permissions in SPECS:
        v[key] = 'old-' + subject
        v[expiry] = str(now + LIFETIME)
        records.append({'subject': subject, 'scope': 'community-brain', 'permissions': permissions,
                        'expires_at': now + LIFETIME, 'sha256': hashlib.sha256(v[key].encode()).hexdigest()})
    v[IDENTITIES] = json.dumps(records)
    return v


class Fake:
    def __init__(self, fail=None):
        self.values = initial()
        self.live = json.loads(self.values[IDENTITIES])
        self.consumers = {k: self.values[k] for k, *_ in SPECS}
        self.fail = fail
        self.effect = 0
        self.revoked = False

    def boundary(self):
        self.effect += 1
        if self.effect == self.fail:
            raise RuntimeError('lost acknowledgment')

    def read(self): return copy.deepcopy(self.values)
    def save(self, updates):
        self.values.update(updates)
        self.boundary()
    def inventory(self, values):
        assert all(self.consumers[k] == values[k] for k in self.consumers)
    def accept(self, values):
        self.live = json.loads(values[IDENTITIES])
        self.boundary()
    def verify_overlap(self, j):
        assert self.live == j['before'] + j['after']
    def deliver(self, j):
        for key in self.consumers:
            self.consumers[key] = j['updates'][key]
            self.boundary()
    def verify_consumers(self, j):
        assert all(self.consumers[k] == j['updates'][k] for k in self.consumers)
        assert all(r in self.live for r in j['after'])
    def verify_revoked(self, j):
        assert all(r not in self.live for r in j['before'])
        self.revoked = True


class RenewalTests(unittest.TestCase):
    def test_due_boundary(self):
        v = initial()
        self.assertFalse(due(v, 1000000 + LIFETIME - LEAD - 1))
        self.assertTrue(due(v, 1000000 + LIFETIME - LEAD))

    def test_future_scheduler_cycle_and_no_early_rotation(self):
        a = Fake()
        self.assertEqual(run(a, 1000000)['state'], 'not_due')
        r = run(a, 1000000 + LIFETIME - LEAD)
        self.assertEqual(r['expires_at'], 1000000 + LIFETIME - LEAD + LIFETIME)
        self.assertEqual(run(a, r['next_due'] - 1)['state'], 'not_due')
        self.assertEqual(run(a, r['next_due'])['state'], 'completed')

    def test_every_effect_crash_resumes_without_new_tokens_or_early_revocation(self):
        baseline = Fake()
        run(baseline, 1000000, force=True)
        for boundary in range(1, baseline.effect + 1):
            with self.subTest(boundary=boundary):
                a = Fake(boundary)
                with self.assertRaises(RuntimeError): run(a, 1000000, force=True)
                j = json.loads(a.values[PENDING])
                cycle = j['cycle']
                if len(a.live) == 5 and a.live != json.loads(initial()[IDENTITIES]):
                    self.assertTrue(all(a.consumers[k] == a.values[k] for k in a.consumers))
                a.fail = None
                r = run(a, 1000100)
                if j['phase'] == 'completed':
                    self.assertEqual(r['state'], 'not_due')
                else:
                    self.assertEqual(r['cycle'], cycle)
                    self.assertEqual(r['expires_at'], 1000000 + LIFETIME)
                    self.assertTrue(a.revoked)

    def test_partial_delivery_retains_overlap(self):
        a = Fake(5)
        with self.assertRaises(RuntimeError): run(a, 1000000, force=True)
        self.assertEqual(len(a.live), 10)
        self.assertFalse(a.revoked)

    def test_scope_drift_fails_before_secret_changes(self):
        a = Fake()
        r = json.loads(a.values[IDENTITIES])
        r[0]['permissions'] = ['jobs:submit']
        a.values[IDENTITIES] = json.dumps(r)
        with self.assertRaises(AssertionError): run(a, 1000000, force=True)
        self.assertEqual(a.effect, 0)

    def test_expired_source_requires_reconciliation(self):
        a = Fake()
        with self.assertRaises(AssertionError): run(a, 1000000 + LIFETIME, force=True)
        self.assertEqual(a.effect, 0)

    def test_completed_journal_has_no_tokens(self):
        a = Fake()
        run(a, 1000000, force=True)
        j = json.loads(a.values[PENDING])
        self.assertNotIn('old', j)
        self.assertNotIn('updates', j)


if __name__ == '__main__': unittest.main()
