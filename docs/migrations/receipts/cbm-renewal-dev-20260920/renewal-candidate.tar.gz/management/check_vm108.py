"""Disposable Docker/SQLite acceptance. Run only on VM108, with sudo Python.
The filter content is synthetic; only its expected hash is substituted in memory.
No application credentials, provider requests or production mounts are used.
"""
from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
import socket
import sqlite3
import subprocess

import renewal_webui_host as host
from test_renewal_webui_host import CONTENT, database

NAME = 'cbm-renewal-stopped-fixture'
VOLUME = 'cbm-renewal-stopped-fixture'
IMAGE = 'sha256:6e7f43ebd7970f89ae9f1afe5d4d77b89448e188e4a580ff9e38bac923d5bc5b'


def main():
    assert socket.gethostname().startswith('community-brain-dev'), 'VM108 only'
    assert os.geteuid() == 0
    os.umask(0o077)
    # Refuse existing names: never remove another run's uncertain fixture.
    assert subprocess.run(['docker', 'container', 'inspect', NAME], capture_output=True).returncode != 0
    assert subprocess.run(['docker', 'volume', 'inspect', VOLUME], capture_output=True).returncode != 0
    host.docker('volume', 'create', VOLUME)
    created = False
    try:
        host.docker('create', '--name', NAME, '--network', 'none', '--memory', '128m',
                    '--mount', 'type=volume,src='+VOLUME+',dst=/app/backend/data', IMAGE,
                    '/usr/local/bin/python3.11', '-c', 'pass')
        created = True
        host.docker('start', '-a', NAME)
        state = host.inspect(NAME)
        root = Path(state['source'])
        path = database(root)
        host.CONTENT_HASH = hashlib.sha256(CONTENT.encode()).hexdigest()
        baseline = subprocess.run(['docker', 'exec', NAME, 'python', '-c', 'print("read-only inventory")'], capture_output=True)
        assert baseline.returncode == 1  # exact stopped-container failure mechanism
        with closing(sqlite3.connect(path)) as db:
            before = db.execute('SELECT * FROM chat').fetchall()
        args = {'url': host.URL, 'mode': 'inspect', 'token': 'old'}
        assert host.run(args, container=NAME)['consumer_state'] == 'stopped'
        args.update(mode='set', token='new', old_token='old')
        result = host.run(args, container=NAME)
        assert result == {'consumer_state': 'stopped', 'stored_credential_verified': True, 'live_context_verified': False}
        host.run(args, container=NAME)  # retry after lost acknowledgment
        args['mode'] = 'verify'
        host.run(args, container=NAME)
        assert host.inspect(NAME) == state
        with closing(sqlite3.connect(path)) as db:
            assert db.execute('PRAGMA integrity_check').fetchone() == ('ok',)
            assert db.execute('SELECT * FROM chat').fetchall() == before
            _, valves = host.read_row(db)
            assert valves == {'api_key': 'new', 'retrieval_url': host.URL, 'min_score': 0.2, 'nested': {'preserve': True}}
        print(json.dumps({'passed': True, 'baseline_stopped_docker_exec_exit': baseline.returncode,
                          'real_docker_volume_and_sqlite': True, 'stored_credential_rotated': True,
                          'idempotent_delivery': True, 'container_state_unchanged': True,
                          'other_data_preserved': True, 'sqlite_integrity': 'ok',
                          'live_webui_validated': False, 'external_calls': 0, 'production_mutations': 0}))
    finally:
        if created:
            host.docker('rm', NAME)
        host.docker('volume', 'rm', VOLUME)


if __name__ == '__main__':
    main()
