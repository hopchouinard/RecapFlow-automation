"""Host-side WebUI renewal; stopped consumers stay stopped and remain inventoried.

Executed by the existing private SSH transport. Tokens arrive only on stdin.
Live delivery still uses the existing authenticated app API and cache probe.
Stopped delivery updates only the filter's api_key in a SQLite transaction.
"""
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys

FID = 'community_brain_filter'
CONTENT_HASH = '12215e67d72775e3d56baa98fc23093196cc8917d887a18a506f188f26a0dc16'
URL = 'https://community-brain.patchoutech.lab/retrieval/query'


def require(condition):
    if not condition:
        raise RuntimeError('WebUI renewal precondition failed')


def docker(*args, payload=None):
    result = subprocess.run(['docker', *args], input=payload, text=True,
                            capture_output=True, timeout=100)
    require(result.returncode == 0)
    return result.stdout


def inspect(container):
    row, = json.loads(docker('inspect', container))
    state = row['State']
    require(state['Status'] in ('running', 'exited'))
    require(not state.get('Paused') and not state.get('Restarting'))
    mounts = [m for m in row['Mounts'] if m['Destination'] == '/app/backend/data']
    require(len(mounts) == 1 and mounts[0]['Type'] == 'volume' and mounts[0]['RW'])
    source = Path(mounts[0]['Source'])
    require(source.is_absolute() and source.resolve() == source)
    stable = {key: state[key] for key in ('Status', 'Running', 'Paused', 'Restarting', 'Pid', 'StartedAt', 'FinishedAt', 'ExitCode', 'OOMKilled')}
    return {'id': row['Id'], 'state': stable, 'source': str(source),
            'restart_count': row['RestartCount']}


def stopped_guard(container, original):
    require(original['state']['Status'] == 'exited')
    require(inspect(container) == original)
    running = docker('ps', '-q').split()
    if running:
        for row in json.loads(docker('inspect', *running)):
            require(all(m.get('Source') != original['source'] for m in row['Mounts']))


def read_row(connection):
    row = connection.execute('SELECT content,valves,is_active,is_global FROM function WHERE id=?', (FID,)).fetchone()
    require(row is not None and row[2:] == (1, 1))
    require(hashlib.sha256(row[0].encode()).hexdigest() == CONTENT_HASH)
    valves = json.loads(row[1])
    require(isinstance(valves, dict) and valves.get('retrieval_url') == URL)
    return row, valves


def run(args, *, container='open-webui', live_script=None):
    require(args.get('mode') in ('inspect', 'set', 'verify'))
    require(args.get('url') == URL and isinstance(args.get('token'), str) and bool(args['token']))
    before = inspect(container)
    running = before['state']['Status'] == 'running'
    # Always establish disk configuration, including the expected prior credential,
    # before a live API update. Reading a live SQLite database uses mode=ro.
    path = Path(before['source']) / 'webui.db'
    require(path.is_file() and not path.is_symlink())
    mode = 'rw' if args['mode'] == 'set' and not running else 'ro'
    connection = sqlite3.connect(path.as_uri() + '?mode=' + mode, uri=True, timeout=5)
    try:
        if not running:
            stopped_guard(container, before)
        connection.execute('BEGIN IMMEDIATE' if mode == 'rw' else 'BEGIN')
        row, valves = read_row(connection)
        allowed = [args['token']]
        if args['mode'] == 'set':
            require(isinstance(args.get('old_token'), str) and bool(args['old_token']))
            allowed.append(args['old_token'])
        require(valves.get('api_key') in allowed)
        if mode == 'rw':
            updated = {**valves, 'api_key': args['token']}
            result = connection.execute('UPDATE function SET valves=? WHERE id=? AND valves=?',
                                        (json.dumps(updated, separators=(',', ':')), FID, row[1]))
            require(result.rowcount == 1)
            after_row, after_valves = read_row(connection)
            require(after_valves == updated and after_row[0] == row[0] and after_row[2:] == row[2:])
            stopped_guard(container, before)
            connection.commit()
            # A lost acknowledgment or concurrent start leaves renewal overlap in
            # place. The next attempt verifies disk/live state before revocation.
            stopped_guard(container, before)
        else:
            connection.rollback()
    finally:
        connection.close()
    if running and args['mode'] in ('set', 'verify'):
        require(isinstance(live_script, str) and bool(live_script))
        payload = {'mode': 'set' if args['mode'] == 'set' else 'verify',
                   'url': URL, 'token': args['token']}
        result = json.loads(docker('exec', '-i', container, 'python', '-c', live_script,
                                   payload=json.dumps(payload)))
        require(result.get('live_app_process') is True and result.get('context_emitted') is True
                and result.get('retrieval_status') == 'ok' and result.get('effective_url') == URL
                and result.get('credential_sha256') == hashlib.sha256(args['token'].encode()).hexdigest())
        require(inspect(container) == before)
        # Confirm the live update persisted, rather than relying on cached valves.
        check = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)
        try:
            _, current = read_row(check)
            require(current.get('api_key') == args['token'])
        finally:
            check.close()
    else:
        require(inspect(container) == before)
    return {'consumer_state': 'running' if running else 'stopped',
            'stored_credential_verified': True,
            'live_context_verified': running and args['mode'] in ('set', 'verify')}


def main():
    os.umask(0o077)
    try:
        result = run(json.load(sys.stdin), live_script=globals().get('LIVE_SCRIPT'))
    except Exception:
        print(json.dumps({'code': 'webui_renewal_requires_review'}), file=sys.stderr)
        return 1
    print(json.dumps(result))
    return 0


if __name__ == '__main__':
    sys.exit(main())
