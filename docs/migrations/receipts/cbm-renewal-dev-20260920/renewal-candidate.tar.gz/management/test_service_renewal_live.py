"""Exercise the real adapter boundary without loading private management context."""
import importlib.util
import json
from pathlib import Path
import sys
from types import ModuleType
import unittest
from unittest.mock import Mock, patch


class AdapterTests(unittest.TestCase):
    def setUp(self):
        modules = {}
        for name in ('secret_store', 'manual_api_runtime', 'manage'):
            modules[name] = ModuleType(name)
        modules['secret_store'].read = Mock()
        modules['secret_store'].save = Mock()
        self.remote = modules['secret_store'].remote = Mock()
        modules['manual_api_runtime'].recreate = Mock()
        modules['manage'].CTX = object()
        with patch.dict(sys.modules, modules):
            spec = importlib.util.spec_from_file_location('candidate_live', Path(__file__).with_name('service_renewal_live.py'))
            self.module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(self.module)
        self.lease = Mock()
        self.adapter = self.module.Adapter(self.lease)

    def test_stopped_consumer_is_not_dropped_and_payload_is_private(self):
        self.remote.return_value = json.dumps({'consumer_state': 'stopped', 'stored_credential_verified': True, 'live_context_verified': False})
        self.adapter.webui('set', 'synthetic-new-secret', 'synthetic-old-secret')
        target, code, payload = self.remote.call_args.args
        self.assertEqual(target, 'n8n-automation')
        self.assertNotIn('synthetic-new-secret', code)
        self.assertNotIn('synthetic-old-secret', code)
        self.assertEqual(payload['token'], 'synthetic-new-secret')
        self.assertEqual(payload['old_token'], 'synthetic-old-secret')
        compile(code, '<host-script>', 'exec')
        self.assertEqual(self.lease.check.call_count, 2)

    def test_running_consumer_requires_live_context(self):
        self.remote.return_value = json.dumps({'consumer_state': 'running', 'stored_credential_verified': True, 'live_context_verified': False})
        with self.assertRaises(AssertionError): self.adapter.webui('verify', 'synthetic-token')

    def test_transport_failure_is_not_skipped_or_retried(self):
        self.remote.side_effect = RuntimeError('Remote management operation failed; private output suppressed')
        with self.assertRaises(RuntimeError): self.adapter.webui('verify', 'synthetic-token')
        self.assertEqual(self.remote.call_count, 1)


if __name__ == '__main__':
    unittest.main()
