from contextlib import closing
import hashlib
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

import renewal_webui_host as host
from test_service_renewal_policy import Fake
from service_renewal_policy import run as renew, PENDING

CONTENT = 'synthetic filter fixture; no private inputs'


def database(root, token='old'):
    path = root/'webui.db'
    with closing(sqlite3.connect(path)) as db, db:
        db.execute('CREATE TABLE function (id TEXT PRIMARY KEY, content TEXT, valves TEXT, is_active INTEGER, is_global INTEGER)')
        db.execute('CREATE TABLE chat (id TEXT PRIMARY KEY, content TEXT)')
        db.execute('INSERT INTO chat VALUES (?,?)', ('preserved', 'synthetic conversation'))
        db.execute('INSERT INTO function VALUES (?,?,?,?,?)', (host.FID, CONTENT, json.dumps({'api_key': token, 'retrieval_url': host.URL, 'min_score': 0.2, 'nested': {'preserve': True}}), 1, 1))
    return path


class WebUITests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.path = database(self.root)
        self.state = {'id': 'fixed-container', 'state': {'Status': 'exited'}, 'source': str(self.root), 'restart_count': 0}
        self.addCleanup(patch.stopall)
        patch.object(host, 'CONTENT_HASH', hashlib.sha256(CONTENT.encode()).hexdigest()).start()
        self.inspect = patch.object(host, 'inspect', side_effect=lambda _: json.loads(json.dumps(self.state))).start()
        self.docker = patch.object(host, 'docker', return_value='').start()

    def args(self, mode='set', token='new'):
        return {'mode': mode, 'url': host.URL, 'token': token, 'old_token': 'old'}

    def rows(self):
        with closing(sqlite3.connect(self.path)) as db, db:
            return db.execute('SELECT * FROM function').fetchall(), db.execute('SELECT * FROM chat').fetchall()

    def test_stopped_inspection_and_delivery_preserve_other_data(self):
        before = self.rows()
        self.assertEqual(host.run(self.args('inspect', 'old'))['consumer_state'], 'stopped')
        result = host.run(self.args())
        self.assertFalse(result['live_context_verified'])
        after = self.rows()
        self.assertEqual(after[1], before[1])
        self.assertEqual(after[0][0][:2], before[0][0][:2])
        self.assertEqual(after[0][0][3:], before[0][0][3:])
        old, new = json.loads(before[0][0][2]), json.loads(after[0][0][2])
        self.assertEqual(new, {**old, 'api_key': 'new'})
        host.run(self.args('verify'))
        host.run(self.args())  # lost-ack replay is compare/set, never a new token
        self.assertEqual(self.rows(), after)
        self.assertTrue(all(call.args[0] == 'ps' for call in self.docker.call_args_list))

    def test_drift_and_wrong_source_fail_without_changes(self):
        for column, value in [('content', 'drift'), ('is_active', 0), ('is_global', 0), ('valves', json.dumps({'api_key': 'unknown', 'retrieval_url': host.URL}))]:
            with self.subTest(column=column):
                original = self.path.read_bytes()
                with closing(sqlite3.connect(self.path)) as db, db:
                    db.execute(f'UPDATE function SET {column}=?', (value,))
                before = self.rows()
                with self.assertRaises(RuntimeError): host.run(self.args())
                self.assertEqual(self.rows(), before)
                self.path.write_bytes(original)

    def test_inspection_is_read_only(self):
        before = self.path.read_bytes()
        host.run(self.args('inspect', 'old'))
        self.assertEqual(self.path.read_bytes(), before)

    def test_start_during_transaction_rolls_back(self):
        before = self.rows()
        calls = 0
        def inspect(_):
            nonlocal calls
            calls += 1
            return {**self.state, 'restart_count': 1} if calls >= 3 else self.state.copy()
        self.inspect.side_effect = inspect
        with self.assertRaises(RuntimeError): host.run(self.args())
        self.assertEqual(self.rows(), before)

    def test_start_after_commit_fails_then_live_verification_required(self):
        calls = 0
        def inspect(_):
            nonlocal calls
            calls += 1
            return {**self.state, 'restart_count': 1} if calls >= 4 else self.state.copy()
        self.inspect.side_effect = inspect
        with self.assertRaises(RuntimeError): host.run(self.args())
        self.assertEqual(json.loads(self.rows()[0][0][2])['api_key'], 'new')

    def test_other_running_volume_user_blocks_write(self):
        self.docker.side_effect = lambda *a, **k: 'other' if a[0] == 'ps' else json.dumps([{'Mounts': [{'Source': str(self.root)}]}])
        before = self.rows()
        with self.assertRaises(RuntimeError): host.run(self.args())
        self.assertEqual(self.rows(), before)

    def test_symlink_database_rejected(self):
        self.path.rename(self.root/'other.db')
        self.path.symlink_to(self.root/'other.db')
        with self.assertRaises(RuntimeError): host.run(self.args())

    def test_live_delivery_uses_api_and_requires_persistence(self):
        self.state['state']['Status'] = 'running'
        result = {'credential_sha256': hashlib.sha256(b'new').hexdigest(), 'live_app_process': True, 'context_emitted': True, 'retrieval_status': 'ok', 'effective_url': host.URL}
        self.docker.return_value = json.dumps(result)
        with self.assertRaises(RuntimeError): host.run(self.args(), live_script='existing-authenticated-api-control')
        def live(*a, payload=None):
            self.assertEqual(a[:3], ('exec', '-i', 'open-webui'))
            token = json.loads(payload)['token']
            with closing(sqlite3.connect(self.path)) as db, db:
                _, valves = host.read_row(db)
                db.execute('UPDATE function SET valves=?', (json.dumps({**valves, 'api_key': token}),))
            return json.dumps(result)
        self.docker.side_effect = live
        self.assertTrue(host.run(self.args(), live_script='existing-authenticated-api-control')['live_context_verified'])
        self.assertTrue(host.run(self.args('verify'), live_script='existing-authenticated-api-control')['live_context_verified'])

    def test_live_cache_failure_never_accepted(self):
        self.state['state']['Status'] = 'running'
        self.docker.return_value = json.dumps({'live_app_process': True, 'context_emitted': False, 'retrieval_status': 'ok', 'effective_url': host.URL})
        with self.assertRaises(RuntimeError): host.run(self.args('verify', 'old'), live_script='probe')

    def test_policy_retains_overlap_after_stopped_delivery_lost_ack(self):
        test = self
        class Adapter(Fake):
            fail_after_disk = True
            def inventory(self, values):
                super().inventory(values)
                host.run(test.args('inspect', values['CB_OPENWEBUI_RETRIEVAL_TOKEN']))
            def deliver(self, journal):
                args = {'mode': 'set', 'url': host.URL, 'token': journal['updates']['CB_OPENWEBUI_RETRIEVAL_TOKEN'], 'old_token': journal['old']['CB_OPENWEBUI_RETRIEVAL_TOKEN']}
                host.run(args)
                if self.fail_after_disk:
                    self.fail_after_disk = False
                    raise RuntimeError('lost disk acknowledgment')
                super().deliver(journal)
            def verify_consumers(self, journal):
                super().verify_consumers(journal)
                host.run(test.args('verify', journal['updates']['CB_OPENWEBUI_RETRIEVAL_TOKEN']))
        adapter = Adapter()
        with closing(sqlite3.connect(self.path)) as db, db:
            _, valves = host.read_row(db)
            db.execute('UPDATE function SET valves=?', (json.dumps({**valves, 'api_key': adapter.values['CB_OPENWEBUI_RETRIEVAL_TOKEN']}),))
        with self.assertRaises(RuntimeError): renew(adapter, 1000000, force=True)
        journal = json.loads(adapter.values[PENDING])
        self.assertEqual(len(adapter.live), 10)
        self.assertFalse(adapter.revoked)
        result = renew(adapter, 1000010)
        self.assertEqual(result['cycle'], journal['cycle'])
        self.assertEqual(len(adapter.live), 5)
        self.assertTrue(adapter.revoked)


if __name__ == '__main__':
    unittest.main()
