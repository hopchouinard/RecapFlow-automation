# Renewal candidate from Request024

This is a development candidate for the existing `agent-ops` management
implementation, not a new secret authority or a deployed management installation.
The verified source reference is preserved in
`docs/migrations/receipts/cbm-renewal-dev-20260920/request024/`.

`service_renewal_policy.py` and its seven tests are unchanged source from
Request024. `service_renewal_live.py` changes only WebUI inspection/delivery/
verification and calls the new `renewal_webui_host.py` through the existing private
SSH transport. `renewal_webui_control.py` additionally verifies the live cache's
credential hash. Source hashes bind the exact before/after files.

The stopped path uses the Docker-inspected named volume and an existing SQLite
file (`mode=rw`, never create). It requires the known filter content, endpoint,
active/global flags and an expected old/new credential. A transaction changes only
`api_key` inside the valves object. State checks and inspection of other running
volume users precede delivery and surround commit. A concurrent start, drift or
lost acknowledgment fails acceptance; the existing renewal journal retains overlap
until verification succeeds. A running consumer still requires the authenticated
WebUI API, persisted valves, live cache credential hash and actual emitted context.
No helper starts, stops, pauses or restarts WebUI.

The Docker checks cannot prevent a separate administrator starting a container in
the final observation window. Production execution must therefore keep the
existing scheduler/quiet lease and exclude concurrent WebUI administration during
renewal. The guard detects observed state changes; it is not a Docker startup lock.
This remains an explicit rollout precondition.

Run the targeted suite on Forge and VM108:

```sh
python3 -m unittest discover -s deploy/community-brain/stabilization/management -p 'test_*.py' -v
```

On VM108, copy this directory to a dedicated workspace and run `sudo python3
<workspace>/management/check_vm108.py`. It refuses other hostnames and existing
fixture names, uses the already validated application image solely for a disposable
stopped container, and removes its own container/volume on completion. Tests use
synthetic SQLite content; the expected filter hash is replaced **in test memory
only**. Production helper constants are unchanged. No production data is copied.

Twenty tests and the real Docker/SQLite stopped-consumer rehearsal pass on VM108.
They do not certify the live OpenWebUI image/API/cache path. Request025 asks the
management owner for that development rehearsal with the exact existing image and
filter code. No production rotation, renderer installation or runner resume is
part of this candidate. Management renderer/image/helper integration and coherent
rollback evidence must be completed before promotion; the old renderer still pins
the prior application overlays.
